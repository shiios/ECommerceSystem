//
//  SMessageViewController.m
//  ECommerceSystem
//
//  Created by yin tian on 2018/11/27.
//  Copyright © 2018 yin tian. All rights reserved.
//

#import "SMessageViewController.h"

@implementation SMessageViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title = @"消息";
}
@end
