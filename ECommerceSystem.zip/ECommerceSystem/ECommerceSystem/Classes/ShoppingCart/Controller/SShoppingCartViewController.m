//
//  SShoppingCartViewController.m
//  ECommerceSystem
//
//  Created by yin tian on 2018/11/27.
//  Copyright © 2018 yin tian. All rights reserved.
//

#import "SShoppingCartViewController.h"

@implementation SShoppingCartViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title = @"购物车";
}
@end
