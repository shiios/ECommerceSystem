//
//  SHomeViewController.h
//  ECommerceSystem
//
//  Created by yin tian on 2018/11/27.
//  Copyright © 2018 yin tian. All rights reserved.
//

#import "SBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface SHomeViewController : SBaseViewController

@end

NS_ASSUME_NONNULL_END
