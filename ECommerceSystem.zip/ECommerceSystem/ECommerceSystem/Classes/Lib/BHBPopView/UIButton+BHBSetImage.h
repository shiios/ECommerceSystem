//
//  UIButton+BHBSetImage.h
//  BHBPopViewDemo
//
//  Created by 毕洪博 on 15/8/15.
//  Copyright (c) 2015年 毕洪博. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (BHBSetImage)

- (void)bhb_setImage:(NSString *)imagePath;
- (void)bhb_setBGImage:(NSString *)imagePath;

@end
