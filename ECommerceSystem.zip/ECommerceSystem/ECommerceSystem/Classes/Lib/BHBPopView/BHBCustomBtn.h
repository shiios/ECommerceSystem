//
//  BHBCustomBtn.h
//  BHBPopViewDemo
//
//  Created by 毕洪博 on 15/8/15.
//  Copyright (c) 2015年 毕洪博. All rights reserved.
//

#import <UIKit/UIKit.h>

#define ICONHEIGHT 71
#define TITLEHEIGHT 30

@interface BHBCustomBtn : UIButton

@end
