//
//  BHBGroup.h
//  BHBPopViewDemo
//
//  Created by bihongbo on 16/3/16.
//  Copyright © 2016年 毕洪博. All rights reserved.
//

#import "BHBItem.h"

@interface BHBGroup : BHBItem

@property (nonatomic, strong) NSArray<BHBItem *> * items;

@end
